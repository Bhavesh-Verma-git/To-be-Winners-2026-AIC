---
title: 'Quickstart: Run a Custom Container on App Service'
description: Learn how to run custom containers by using Azure App Service.
author: msangapu-msft
ms.author: msangapu
ms.date: 04/20/2026
ms.topic: quickstart
ms.custom: devx-track-csharp, mode-other, devdivchpfy22, linux-related-content
zone_pivot_groups: app-service-containers-windows-linux-portal-ps-cli
#customer intent: As an app developer who uses Azure App Service, I want to use a container to deploy and manage an app.
ms.service: azure-app-service
---

# Quickstart: Run a custom container in Azure

::: zone pivot="container-windows-vs"
[!INCLUDE [quickstart-custom-container-windows-visual-studio-pivot.md](includes/quickstart-custom-container/quickstart-custom-container-windows-visual-studio-pivot.md)]
::: zone-end  

::: zone pivot="container-linux-vscode"
[!INCLUDE [quickstart-custom-container-linux-visual-studio-code-pivot.md](includes/quickstart-custom-container/quickstart-custom-container-linux-visual-studio-code-pivot.md)]
::: zone-end

:::zone pivot="container-linux-azure-portal"
[!INCLUDE [quickstart-custom-container-linux-azure-portal-pivot.md](includes/quickstart-custom-container/quickstart-custom-container-linux-azure-portal-pivot.md)]
::: zone-end

:::zone pivot="container-windows-azure-portal"
[!INCLUDE [quickstart-custom-container-windows-azure-portal-pivot.md](includes/quickstart-custom-container/quickstart-custom-container-windows-azure-portal-pivot.md)]
::: zone-end

:::zone pivot="container-windows-powershell"
[!INCLUDE [quickstart-custom-container-windows-powershell-pivot.md](includes/quickstart-custom-container/quickstart-custom-container-windows-powershell-pivot.md)]
::: zone-end

:::zone pivot="container-windows-cli"
[!INCLUDE [quickstart-custom-container-windows-cli-pivot.md](includes/quickstart-custom-container/quickstart-custom-container-windows-cli-pivot.md)]
::: zone-end
